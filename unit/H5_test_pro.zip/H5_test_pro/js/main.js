//here is your code...
summerready = function () {
    alert("main..")
};